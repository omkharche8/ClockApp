// Export pages
export '/pages/splash_screen/splash_screen_widget.dart' show SplashScreenWidget;
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/register/register_widget.dart' show RegisterWidget;
export '/pages/home/home_widget.dart' show HomeWidget;
export '/pages/profile/profile_widget.dart' show ProfileWidget;
