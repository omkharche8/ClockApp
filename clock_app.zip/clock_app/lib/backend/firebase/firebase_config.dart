import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCq89u7yhqXnqpzAy3QP-hW5zwF8dAW7nU",
            authDomain: "clockapp-c89c6.firebaseapp.com",
            projectId: "clockapp-c89c6",
            storageBucket: "clockapp-c89c6.appspot.com",
            messagingSenderId: "561597858683",
            appId: "1:561597858683:web:e53c951c28435c4210b3de",
            measurementId: "G-L2FTB53XVH"));
  } else {
    await Firebase.initializeApp();
  }
}
